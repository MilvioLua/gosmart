<?php
	require_once(sprintf("%s/aweber_api.php", dirname(__FILE__)));
?>