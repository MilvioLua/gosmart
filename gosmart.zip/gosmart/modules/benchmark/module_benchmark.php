<?php
	require_once(sprintf("%s/benchmark_api.php", dirname(__FILE__)));
?>