<?php
require_once(sprintf("%s/campaignmonitor_api.php", dirname(__FILE__)));
?>