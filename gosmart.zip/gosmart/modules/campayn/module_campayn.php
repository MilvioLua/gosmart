<?php
	require_once(sprintf("%s/campayn_api.php", dirname(__FILE__)));
?>