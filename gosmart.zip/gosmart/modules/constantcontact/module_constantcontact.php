<?php
   require_once(sprintf("%s/constantcontact_api.php", dirname(__FILE__)));
?>