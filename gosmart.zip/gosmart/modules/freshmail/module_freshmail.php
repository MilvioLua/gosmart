<?php
   require_once(sprintf("%s/freshmail_api.php", dirname(__FILE__)));
?>