<?php
	require_once(sprintf("%s/klicktipp_api.php", dirname(__FILE__)));
?>