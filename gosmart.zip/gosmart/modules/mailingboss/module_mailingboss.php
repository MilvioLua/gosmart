<?php
	require_once(sprintf("%s/mailingboss_api.php", dirname(__FILE__)));
?>