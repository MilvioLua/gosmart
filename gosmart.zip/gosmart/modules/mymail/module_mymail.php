<?php
   require_once(sprintf("%s/mymail_api.php", dirname(__FILE__)));
?>