<?php
   require_once(sprintf("%s/simplycast_api.php", dirname(__FILE__)));
?>